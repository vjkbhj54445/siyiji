# API（10 个最小接口）

> 启动后可访问 http://localhost:8000/docs 查看 OpenAPI 文档（交互式）。

1. `GET /health` 健康检查  
2. `GET /version` 版本信息  
3. `GET /scripts` 列出可用脚本（来自 `scripts/manifest.json`）  
4. `GET /scripts/{script_id}` 获取脚本详情  
5. `POST /tasks` 创建待办任务  
6. `GET /tasks` 列出任务（可选 `?status=todo`）  
7. `PATCH /tasks/{task_id}` 更新任务  
8. `DELETE /tasks/{task_id}` 删除任务  
9. `POST /runs` 触发脚本执行（异步入队列）  
10. `GET /runs` 列出运行记录（默认 50 条）  
11. `GET /runs/{run_id}` 获取运行详情（包含 stdout/stderr tail）  

> 注：第 11 个是为了“可用性”额外给的（你可以把它当成必选接口之一）。
