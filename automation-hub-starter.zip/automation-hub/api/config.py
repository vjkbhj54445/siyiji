from __future__ import annotations

import os
import json
from pathlib import Path
from typing import Any, Dict

REDIS_URL = os.environ.get("REDIS_URL", "redis://redis:6379/0")
QUEUE_NAME = os.environ.get("QUEUE_NAME", "default")

RUNS_DIR = Path(os.environ.get("RUNS_DIR", "/data/runs"))
RUNS_DIR.mkdir(parents=True, exist_ok=True)

SCRIPTS_MANIFEST_PATH = Path(os.environ.get("SCRIPTS_MANIFEST", "/app/scripts/manifest.json"))


def load_scripts_manifest() -> Dict[str, Any]:
    data = json.loads(SCRIPTS_MANIFEST_PATH.read_text(encoding="utf-8"))
    # expected: {"scripts": [{"id":..., "name":..., "command": [...], "timeout_sec": int, "description":...}]}
    return data
