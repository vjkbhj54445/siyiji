from __future__ import annotations

from fastapi import FastAPI

from api.db import init_db
from api.routes.health import router as health_router
from api.routes.meta import router as meta_router
from api.routes.scripts import router as scripts_router
from api.routes.tasks import router as tasks_router
from api.routes.runs import router as runs_router

app = FastAPI(title="Automation Hub", version="0.1.0")


@app.on_event("startup")
def _startup():
    init_db()


app.include_router(health_router)
app.include_router(meta_router)
app.include_router(scripts_router)
app.include_router(tasks_router)
app.include_router(runs_router)
