from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, HTTPException
from redis import Redis
from rq import Queue

from api.config import QUEUE_NAME, REDIS_URL, RUNS_DIR, load_scripts_manifest
from api.db import connect, execute, fetch_all, fetch_one
from api.models import RunCreate, RunOut

router = APIRouter()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def tail_text(path: str | None, max_chars: int = 2000) -> str | None:
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        return None
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
        return text[-max_chars:]
    except Exception:
        data = p.read_bytes()
        return data[-max_chars:].decode("utf-8", errors="replace")


def get_script(script_id: str) -> dict:
    manifest = load_scripts_manifest()
    for s in manifest.get("scripts", []):
        if s.get("id") == script_id:
            return s
    raise HTTPException(status_code=404, detail="script not found")


@router.post("/runs")
def create_run(payload: RunCreate):
    # Validate script exists
    _ = get_script(payload.script_id)

    run_id = str(uuid.uuid4())
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    stdout_path = str(run_dir / "stdout.txt")
    stderr_path = str(run_dir / "stderr.txt")

    conn = connect()
    try:
        execute(
            conn,
            """
            INSERT INTO runs (id, script_id, args_json, status, created_at, stdout_path, stderr_path)
            VALUES (?, ?, ?, 'queued', ?, ?, ?)
            """,
            (run_id, payload.script_id, json.dumps(payload.args, ensure_ascii=False), now_iso(), stdout_path, stderr_path),
        )
    finally:
        conn.close()

    # Enqueue to worker
    redis_conn = Redis.from_url(REDIS_URL)
    q = Queue(name=QUEUE_NAME, connection=redis_conn)
    q.enqueue("worker.jobs.run_script_job", run_id, payload.script_id, payload.args)

    return {"run_id": run_id, "status": "queued"}


@router.get("/runs")
def list_runs(limit: int = 50):
    conn = connect()
    try:
        rows = fetch_all(conn, "SELECT * FROM runs ORDER BY created_at DESC LIMIT ?", (limit,))
        for r in rows:
            r["args"] = json.loads(r.get("args_json") or "{}")
            r.pop("args_json", None)
        return {"runs": rows}
    finally:
        conn.close()


@router.get("/runs/{run_id}")
def get_run(run_id: str) -> RunOut:
    conn = connect()
    try:
        row = fetch_one(conn, "SELECT * FROM runs WHERE id = ?", (run_id,))
        if not row:
            raise HTTPException(status_code=404, detail="run not found")
        args = json.loads(row.get("args_json") or "{}")
        out = RunOut(
            id=row["id"],
            script_id=row["script_id"],
            status=row["status"],
            created_at=row["created_at"],
            started_at=row.get("started_at"),
            finished_at=row.get("finished_at"),
            exit_code=row.get("exit_code"),
            error=row.get("error"),
            stdout_tail=tail_text(row.get("stdout_path")),
            stderr_tail=tail_text(row.get("stderr_path")),
            args=args,
        )
        return out
    finally:
        conn.close()
