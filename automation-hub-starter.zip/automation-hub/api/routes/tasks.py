from __future__ import annotations

import json
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from api.db import connect, execute, fetch_all, fetch_one
from api.models import TaskCreate, TaskUpdate

router = APIRouter()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@router.post("/tasks")
def create_task(payload: TaskCreate):
    conn = connect()
    try:
        ts = now_iso()
        execute(
            conn,
            """
            INSERT INTO tasks (title, description, tags, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (payload.title, payload.description, json.dumps(payload.tags, ensure_ascii=False), payload.status, ts, ts),
        )
        task = fetch_one(conn, "SELECT * FROM tasks ORDER BY id DESC LIMIT 1")
        task["tags"] = json.loads(task["tags"])
        return task
    finally:
        conn.close()


@router.get("/tasks")
def list_tasks(status: str | None = None):
    conn = connect()
    try:
        if status:
            rows = fetch_all(conn, "SELECT * FROM tasks WHERE status = ? ORDER BY id DESC", (status,))
        else:
            rows = fetch_all(conn, "SELECT * FROM tasks ORDER BY id DESC")
        for r in rows:
            r["tags"] = json.loads(r["tags"])
        return {"tasks": rows}
    finally:
        conn.close()


@router.patch("/tasks/{task_id}")
def update_task(task_id: int, payload: TaskUpdate):
    conn = connect()
    try:
        existing = fetch_one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
        if not existing:
            raise HTTPException(status_code=404, detail="task not found")

        title = payload.title if payload.title is not None else existing["title"]
        desc = payload.description if payload.description is not None else existing["description"]
        tags = payload.tags if payload.tags is not None else json.loads(existing["tags"])
        status = payload.status if payload.status is not None else existing["status"]
        ts = now_iso()

        execute(
            conn,
            """
            UPDATE tasks
            SET title=?, description=?, tags=?, status=?, updated_at=?
            WHERE id=?
            """,
            (title, desc, json.dumps(tags, ensure_ascii=False), status, ts, task_id),
        )

        row = fetch_one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
        row["tags"] = json.loads(row["tags"])
        return row
    finally:
        conn.close()


@router.delete("/tasks/{task_id}")
def delete_task(task_id: int):
    conn = connect()
    try:
        existing = fetch_one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
        if not existing:
            raise HTTPException(status_code=404, detail="task not found")
        execute(conn, "DELETE FROM tasks WHERE id = ?", (task_id,))
        return {"deleted": True, "task_id": task_id}
    finally:
        conn.close()
