from __future__ import annotations

from fastapi import APIRouter, HTTPException

from api.config import load_scripts_manifest

router = APIRouter()


@router.get("/scripts")
def list_scripts():
    manifest = load_scripts_manifest()
    scripts = manifest.get("scripts", [])
    return {"scripts": scripts}


@router.get("/scripts/{script_id}")
def get_script(script_id: str):
    manifest = load_scripts_manifest()
    for s in manifest.get("scripts", []):
        if s.get("id") == script_id:
            return s
    raise HTTPException(status_code=404, detail="script not found")
