from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/version")
def version():
    return {"name": "automation-hub", "version": "0.1.0"}
