from __future__ import annotations

import os

from redis import Redis
from rq import Connection, Queue, Worker

REDIS_URL = os.environ.get("REDIS_URL", "redis://redis:6379/0")
QUEUE_NAME = os.environ.get("QUEUE_NAME", "default")


def main() -> None:
    redis_conn = Redis.from_url(REDIS_URL)
    with Connection(redis_conn):
        q = Queue(QUEUE_NAME)
        w = Worker([q])
        w.work(with_scheduler=False)


if __name__ == "__main__":
    main()
