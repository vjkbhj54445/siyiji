from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from api.config import load_scripts_manifest
from api.db import connect, execute, fetch_one


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_script(script_id: str) -> dict:
    manifest = load_scripts_manifest()
    for s in manifest.get("scripts", []):
        if s.get("id") == script_id:
            return s
    raise ValueError(f"script not found: {script_id}")


def build_command(script: dict, args: Dict[str, Any]) -> List[str]:
    # command is a list like ["python","/app/scripts/xxx.py"]
    cmd = list(script["command"])
    arg_style = script.get("arg_style", "flags")  # "flags" or "positional"

    if arg_style == "flags":
        # Convert args dict to CLI flags: --key value
        for k, v in args.items():
            flag = f"--{k.replace('_','-')}"
            cmd.append(flag)
            if isinstance(v, bool):
                cmd.append("true" if v else "false")
            else:
                cmd.append(str(v))
    elif arg_style == "positional":
        for k in script.get("positional_args", []):
            if k in args:
                cmd.append(str(args[k]))
    return cmd


def run_script_job(run_id: str, script_id: str, args: Dict[str, Any]) -> None:
    script = get_script(script_id)

    conn = connect()
    try:
        row = fetch_one(conn, "SELECT * FROM runs WHERE id = ?", (run_id,))
        if not row:
            return

        stdout_path = Path(row["stdout_path"])
        stderr_path = Path(row["stderr_path"])
        stdout_path.parent.mkdir(parents=True, exist_ok=True)

        execute(conn, "UPDATE runs SET status='running', started_at=? WHERE id=?", (now_iso(), run_id))

        timeout = int(script.get("timeout_sec", 120))
        cmd = build_command(script, args)

        env = os.environ.copy()
        env["WORKSPACE"] = env.get("WORKSPACE", "/workspace")

        with stdout_path.open("w", encoding="utf-8") as out_f, stderr_path.open("w", encoding="utf-8") as err_f:
            try:
                proc = subprocess.run(
                    cmd,
                    cwd=script.get("cwd", "/app"),
                    env=env,
                    stdout=out_f,
                    stderr=err_f,
                    text=True,
                    timeout=timeout,
                    check=False,
                )
                exit_code = proc.returncode
                status = "succeeded" if exit_code == 0 else "failed"
                execute(
                    conn,
                    "UPDATE runs SET status=?, finished_at=?, exit_code=? WHERE id=?",
                    (status, now_iso(), exit_code, run_id),
                )
            except subprocess.TimeoutExpired:
                err_f.write(f"\n[automation-hub] Timeout after {timeout}s\n")
                execute(
                    conn,
                    "UPDATE runs SET status='failed', finished_at=?, exit_code=?, error=? WHERE id=?",
                    (now_iso(), 124, f"timeout after {timeout}s", run_id),
                )
            except Exception as e:
                err_f.write(f"\n[automation-hub] Exception: {e}\n")
                execute(
                    conn,
                    "UPDATE runs SET status='failed', finished_at=?, exit_code=?, error=? WHERE id=?",
                    (now_iso(), 1, str(e), run_id),
                )
    finally:
        conn.close()
